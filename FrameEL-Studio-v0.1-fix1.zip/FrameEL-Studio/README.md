# FrameEL Studio — Android prototype v0.1

WebView app that runs the HTML Cut-page prototype and exports the timeline as MP4 with AndroidX Media3 Transformer.

**Status: source project only. It has NOT been compiled or run on a device** (the environment that created it has no Android SDK and no network). Treat the first build as a test: send me the build log if Gradle or Kotlin reports errors.

## What works (by design, untested on a device)
- Pick videos with the Storage Access Framework (WebView file chooser -> system picker). No storage permission needed.
- Source Tape, preview, dual timeline, Split, Delete, Ripple trim, Unlink audio, Nudge, Undo/Redo (same code as the HTML prototype v2).
- Export MP4: clips in timeline order with their In/Out points, output size = size of the first clip (max 1920 px), H.264 + AAC.
- Linked audio travels with its clip; unlinked (separated) audio clips are placed at their timeline position (gaps are silent), cut at the video end. "Mute A1" exports without audio.
- Progress bar, success/error message, Cancel. The file is saved to **Movies/FrameEL Studio/**.
- While exporting: foreground service + notification and screen kept on, so Android is less likely to kill the app.

## Not included in v0.1
Project save/load, effects, transitions, titles, speed changes, per-clip volume, account/cloud/paid APIs. The Export button only appears inside the app (hidden in a normal browser).

## Build the APK without a PC (GitHub Actions)
1. Create a free GitHub account and a new empty repository.
2. In the repo choose Add file -> Create new file. Type the full path as the file name (typing `/` creates folders) and paste the file content. Files:
   `.github/workflows/build-apk.yml`, `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`,
   `gradle/wrapper/gradle-wrapper.properties`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`,
   `app/src/main/assets/index.html`, and under `app/src/main/java/com/framecut/studio/`:
   `MainActivity.kt`, `MediaRegistry.kt`, `ExportManager.kt`, `ExportService.kt`.
3. Open the Actions tab -> "Build APK" run (3-8 min). When green, open the run, download the artifact `FrameEL-Studio-v0.1-debug-apk` (a zip), unzip it in your Files app and install the APK (allow "install unknown apps").
4. If the run is red, open the failed step and send me the error text.

## Build with Android Studio (if you get a PC)
Open the folder, let Gradle sync (JDK 17), then Build -> Build APK(s). Output: `app/build/outputs/apk/debug/FrameEL-Studio-v0.1-debug.apk`.

## Requirements
Android 10+ (minSdk 29), debug-signed APK (not for Play Store).

## Known limits / things to verify on a phone
- Media3 version is pinned to 1.7.1; Transformer APIs used (sequences, gaps, forced audio track) are from the official docs but were not compiled here.
- Source files are matched to export by "name|size"; two different files with the same name and size would collide.
- Waveforms are skipped for files over 60 MB (memory); editing still works.
- Very large or high-bitrate files may be slow or fail on weak devices; try short clips first.
