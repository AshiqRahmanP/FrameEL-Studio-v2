package com.framecut.studio

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Turns the timeline sent by the web page into a Media3 Composition, exports it as MP4 into the
 * app cache, then copies it to Movies/FrameEL Studio using MediaStore. Call everything on the main thread.
 *
 * Job JSON: { mute, video:[{key,in,out,linked}], audio:[{key,in,out,start}] }  (all times in ms)
 */
object ExportManager {
    interface Callbacks {
        fun running(on: Boolean)
        fun progress(percent: Int)
        fun done(fileName: String)
        fun error(message: String)
    }

    var callbacks: Callbacks? = null

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var transformer: Transformer? = null
    private var appCtx: Context? = null
    private var outFile: File? = null

    fun start(ctx: Context, json: String) {
        if (transformer != null) {
            callbacks?.error("An export is already running"); return
        }
        val app = ctx.applicationContext
        appCtx = app
        val composition = try {
            buildComposition(app, JSONObject(json))
        } catch (e: Exception) {
            callbacks?.error(e.message ?: "Could not build the composition"); return
        }
        val file = File(app.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        outFile = file
        ContextCompat.startForegroundService(app, Intent(app, ExportService::class.java))
        callbacks?.running(true)
        callbacks?.progress(0)
        try {
            val t = Transformer.Builder(app)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        saveAndFinish(file)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        fail("Export failed (${exportException.errorCodeName})")
                    }
                })
                .build()
            transformer = t
            t.start(composition, file.absolutePath)
            poll(t)
        } catch (e: Exception) {
            fail(e.message ?: "Could not start the export")
        }
    }

    fun cancel() {
        val t = transformer ?: return
        t.cancel()
        fail("Export cancelled")
    }

    // ---- composition -------------------------------------------------------------------------

    private fun clip(uri: Uri, startMs: Long, endMs: Long) = EditedMediaItem.Builder(
        MediaItem.Builder().setUri(uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs)
                .setEndPositionMs(endMs)
                .build()
        ).build()
    )

    private fun uriFor(key: String): Uri =
        MediaRegistry.find(key) ?: error("Source file not found: ${key.substringBeforeLast('|')}. Import it again.")

    private class AudioClip(val uri: Uri, val inMs: Long, var outMs: Long, val startMs: Long)

    private fun buildComposition(ctx: Context, job: JSONObject): Composition {
        val mute = job.optBoolean("mute", false)
        val video = job.getJSONArray("video")
        require(video.length() > 0) { "The timeline is empty" }

        val (w, h) = outputSize(ctx, uriFor(video.getJSONObject(0).getString("key")))
        val fit: Effect = Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT)

        var totalMs = 0L
        var anySilenced = mute
        val videoItems = ArrayList<EditedMediaItem>()
        for (i in 0 until video.length()) {
            val o = video.getJSONObject(i)
            val s = o.getLong("in")
            val e = o.getLong("out")
            require(e - s >= 100) { "A clip is shorter than 0.1 s" }
            totalMs += e - s
            val silent = mute || !o.optBoolean("linked", true)
            if (silent) anySilenced = true
            videoItems += clip(uriFor(o.getString("key")), s, e)
                .setRemoveAudio(silent)
                .setEffects(Effects(emptyList(), listOf(fit)))
                .build()
        }
        val videoTrackTypes = if (anySilenced) {
            setOf(C.TRACK_TYPE_AUDIO, C.TRACK_TYPE_VIDEO)
        } else {
            setOf(C.TRACK_TYPE_AUDIO, C.TRACK_TYPE_VIDEO)
        }
        val videoSeqBuilder = EditedMediaItemSequence.Builder(videoTrackTypes).addItems(videoItems)
        val videoSeq = videoSeqBuilder.build()
        val sequences = arrayListOf(videoSeq)

        // Separated (unlinked) audio clips: placed at their timeline start with gaps, cut at the video end.
        if (!mute) {
            val audio = job.optJSONArray("audio")
            val clips = ArrayList<AudioClip>()
            if (audio != null) for (i in 0 until audio.length()) {
                val o = audio.getJSONObject(i)
                val start = o.getLong("start")
                val inMs = o.getLong("in")
                var outMs = o.getLong("out")
                if (start >= totalMs) continue
                if (start + (outMs - inMs) > totalMs) outMs = inMs + (totalMs - start)
                if (outMs - inMs < 100) continue
                clips += AudioClip(uriFor(o.getString("key")), inMs, outMs, start)
            }
            clips.sortBy { it.startMs }
            val lanes = ArrayList<ArrayList<AudioClip>>()
            val laneEnds = ArrayList<Long>()
            for (c in clips) {
                var lane = laneEnds.indexOfFirst { it <= c.startMs }
                if (lane < 0) {
                    lanes += ArrayList(); laneEnds += 0L; lane = lanes.size - 1
                }
                lanes[lane] += c
                laneEnds[lane] = c.startMs + (c.outMs - c.inMs)
            }
            for (lane in lanes) {
                val b = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
                var cursor = 0L
                for (c in lane) {
                    if (c.startMs > cursor) b.addGap((c.startMs - cursor) * 1000L)
                    b.addItem(clip(c.uri, c.inMs, c.outMs).setRemoveVideo(true).build())
                    cursor = c.startMs + (c.outMs - c.inMs)
                }
                sequences += b.build()
            }
        }
        return Composition.Builder(sequences).build()
    }

    /** Output size = size of the first clip (rotation applied), long edge limited to 1920. */
    private fun outputSize(ctx: Context, uri: Uri): Pair<Int, Int> {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            val scale = minOf(1f, 1920f / maxOf(w, h))
            return Pair(((w * scale).toInt() / 2) * 2, ((h * scale).toInt() / 2) * 2)
        } finally {
            r.release()
        }
    }

    // ---- progress, saving, cleanup ---------------------------------------------------------

    private fun poll(t: Transformer) {
        val holder = ProgressHolder()
        val r = object : Runnable {
            override fun run() {
                if (transformer !== t) return
                if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    callbacks?.progress(holder.progress)
                }
                main.postDelayed(this, 500)
            }
        }
        main.postDelayed(r, 500)
    }

    private fun saveAndFinish(file: File) {
        val app = appCtx ?: return
        transformer = null
        io.execute {
            try {
                val name = saveToMovies(app, file)
                main.post { cleanup(file); callbacks?.progress(100); callbacks?.done(name) }
            } catch (e: Exception) {
                main.post { cleanup(file); callbacks?.error("Saving failed: ${e.message}") }
            }
        }
    }

    private fun fail(message: String) {
        val f = outFile
        transformer = null
        if (f != null) cleanup(f)
        callbacks?.error(message)
    }

    private fun cleanup(file: File) {
        transformer = null
        file.delete()
        appCtx?.let { it.stopService(Intent(it, ExportService::class.java)) }
        callbacks?.running(false)
    }

    private fun saveToMovies(ctx: Context, src: File): String {
        val name = "FrameCut_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FrameEL Studio")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val cr = ctx.contentResolver
        val uri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Could not create a file in Movies")
        try {
            cr.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            cr.update(uri, values, null, null)
        } catch (e: Exception) {
            cr.delete(uri, null, null)
            throw e
        }
        return name
    }
}
