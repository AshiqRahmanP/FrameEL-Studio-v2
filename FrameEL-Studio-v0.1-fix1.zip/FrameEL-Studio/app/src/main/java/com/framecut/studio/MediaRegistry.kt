package com.framecut.studio

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns

/**
 * Remembers the content:// Uri of every file the user picked, so the export can read the
 * original file. The web page only sees File objects, so files are matched by "name|size".
 */
object MediaRegistry {
    private val byKey = HashMap<String, Uri>()
    private val byName = HashMap<String, Uri>()

    fun add(cr: ContentResolver, uri: Uri) {
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val name = c.getString(0) ?: return
                val size = if (c.isNull(1)) -1L else c.getLong(1)
                byKey["$name|$size"] = uri
                byName[name] = uri
            }
        }
    }

    fun find(key: String): Uri? = byKey[key] ?: byName[key.substringBeforeLast('|')]
}
