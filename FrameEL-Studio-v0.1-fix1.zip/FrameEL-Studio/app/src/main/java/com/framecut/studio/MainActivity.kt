package com.framecut.studio

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    // Storage Access Framework picker: no storage permission needed, the user grants each file.
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { u ->
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            MediaRegistry.add(contentResolver, u)
        }
        chooser?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        chooser = null
    }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun js(code: String) = runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        // Serves app/src/main/assets over a secure https origin (no network is used).
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            webViewClient = object : WebViewClientCompat() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView,
                    callback: ValueCallback<Array<Uri>>,
                    params: FileChooserParams
                ): Boolean {
                    chooser?.onReceiveValue(null)
                    chooser = callback
                    picker.launch(arrayOf("video/*"))
                    return true
                }
            }
            addJavascriptInterface(Bridge(), "FrameCutAndroid")
        }
        setContentView(web)

        ExportManager.callbacks = object : ExportManager.Callbacks {
            override fun running(on: Boolean) {
                runOnUiThread {
                    if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            override fun progress(percent: Int) = js("window.onExportProgress&&window.onExportProgress($percent)")
            override fun done(fileName: String) =
                js("window.onExportDone&&window.onExportDone(${JSONObject.quote(fileName)})")

            override fun error(message: String) =
                js("window.onExportError&&window.onExportError(${JSONObject.quote(message)})")
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onDestroy() {
        ExportManager.callbacks = null
        super.onDestroy()
    }

    /** Functions the web page can call as window.FrameCutAndroid.* */
    inner class Bridge {
        @JavascriptInterface
        fun startExport(json: String) {
            runOnUiThread { ExportManager.start(applicationContext, json) }
        }

        @JavascriptInterface
        fun cancelExport() {
            runOnUiThread { ExportManager.cancel() }
        }
    }
}
